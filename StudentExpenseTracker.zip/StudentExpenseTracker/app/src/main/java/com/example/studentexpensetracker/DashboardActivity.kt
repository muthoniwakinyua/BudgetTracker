package com.example.studentexpensetracker

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        val prefs = getSharedPreferences("sets_prefs", Context.MODE_PRIVATE)
        val userId = prefs.getInt("user_id", -1)
        val db = DatabaseHelper(this)

        val income = db.getTotal(userId, "income")
        val expense = db.getTotal(userId, "expense")

        findViewById<TextView>(R.id.tvWelcome).text = "Hello, " + db.getUserName(userId)
        findViewById<TextView>(R.id.tvIncome).text = "Income: KES " + "%.2f".format(income)
        findViewById<TextView>(R.id.tvExpense).text = "Expenses: KES " + "%.2f".format(expense)
        findViewById<TextView>(R.id.tvBalance).text = "KES " + "%.2f".format(income - expense)

        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            prefs.edit().remove("user_id").apply()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}