package com.example.studentexpensetracker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "sets.db", null, 1) {

    override fun onConfigure(db: SQLiteDatabase) {
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE users (
                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'student',
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP)"""
        )
        db.execSQL(
            """CREATE TABLE categories (
                category_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                name TEXT NOT NULL,
                is_default INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE)"""
        )
        db.execSQL(
            """CREATE TABLE transactions (
                transaction_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                category_id INTEGER,
                type TEXT NOT NULL,
                amount REAL NOT NULL,
                transaction_date TEXT NOT NULL,
                payment_method TEXT,
                note TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
                FOREIGN KEY (category_id) REFERENCES categories(category_id))"""
        )
        db.execSQL(
            """CREATE TABLE budgets (
                budget_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                category_id INTEGER,
                budget_month TEXT NOT NULL,
                limit_amount REAL NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
                FOREIGN KEY (category_id) REFERENCES categories(category_id))"""
        )
        db.execSQL(
            """CREATE TABLE alerts (
                alert_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                budget_id INTEGER,
                alert_type TEXT NOT NULL,
                message TEXT NOT NULL,
                is_read INTEGER NOT NULL DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
                FOREIGN KEY (budget_id) REFERENCES budgets(budget_id) ON DELETE CASCADE)"""
        )

        val defaults = listOf(
            "Food", "Transport", "Rent", "Airtime",
            "Books", "Entertainment", "Other"
        )
        for (name in defaults) {
            val values = ContentValues()
            values.put("name", name)
            values.put("is_default", 1)
            db.insert("categories", null, values)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS alerts")
        db.execSQL("DROP TABLE IF EXISTS budgets")
        db.execSQL("DROP TABLE IF EXISTS transactions")
        db.execSQL("DROP TABLE IF EXISTS categories")
        db.execSQL("DROP TABLE IF EXISTS users")
        onCreate(db)
    }
    fun registerUser(name: String, email: String, passwordHash: String): Boolean {
        val values = ContentValues()
        values.put("full_name", name)
        values.put("email", email)
        values.put("password_hash", passwordHash)
        val result = writableDatabase.insert("users", null, values)
        return result != -1L
    }
    fun loginUser(email: String, passwordHash: String): Int {
        val cursor = readableDatabase.rawQuery(
            "SELECT user_id FROM users WHERE email = ? AND password_hash = ? AND is_active = 1",
            arrayOf(email, passwordHash)
        )
        var userId = -1
        if (cursor.moveToFirst()) userId = cursor.getInt(0)
        cursor.close()
        return userId
    }
    fun getUserName(userId: Int): String {
        val cursor = readableDatabase.rawQuery(
            "SELECT full_name FROM users WHERE user_id = ?", arrayOf(userId.toString())
        )
        var name = ""
        if (cursor.moveToFirst()) name = cursor.getString(0)
        cursor.close()
        return name
    }

    fun getTotal(userId: Int, type: String): Double {
        val cursor = readableDatabase.rawQuery(
            "SELECT SUM(amount) FROM transactions WHERE user_id = ? AND type = ?",
            arrayOf(userId.toString(), type)
        )
        var total = 0.0
        if (cursor.moveToFirst()) total = cursor.getDouble(0)
        cursor.close()
        return total
    }
}
