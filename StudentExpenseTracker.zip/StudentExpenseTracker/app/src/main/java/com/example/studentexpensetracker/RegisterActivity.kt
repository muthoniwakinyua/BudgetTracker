package com.example.studentexpensetracker

import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.security.MessageDigest

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val etName = findViewById<EditText>(R.id.etName)
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val etConfirm = findViewById<EditText>(R.id.etConfirm)
        val btnRegister = findViewById<Button>(R.id.btnRegister)
        val tvLogin = findViewById<TextView>(R.id.tvLogin)
        val db = DatabaseHelper(this)

        btnRegister.setOnClickListener {
            val name = etName.text.toString().trim()
            val email = etEmail.text.toString().trim().lowercase()
            val password = etPassword.text.toString()
            val confirm = etConfirm.text.toString()

            if (name.isEmpty()) {
                etName.error = "Enter your name"
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                etEmail.error = "Enter a valid email"
            } else if (password.length < 6) {
                etPassword.error = "At least 6 characters"
            } else if (password != confirm) {
                etConfirm.error = "Passwords do not match"
            } else if (db.registerUser(name, email, hashPassword(password))) {
                Toast.makeText(this, "Account created. Please log in.", Toast.LENGTH_LONG).show()
                finish()
            } else {
                etEmail.error = "This email is already registered"
            }
        }

        tvLogin.setOnClickListener { finish() }
    }

    private fun hashPassword(password: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(password.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}